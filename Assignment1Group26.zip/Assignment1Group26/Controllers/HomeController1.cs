﻿using Microsoft.AspNetCore.Mvc;

namespace Assignment1Group26.Controllers
{
    public class HomeController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

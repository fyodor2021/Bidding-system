﻿using System.Net;
using System.Net.Mail;

namespace Assignment1Group26.Service
{
    public class EmailSender : IEmailSender
    {
        public Task SendEmailAsync(string email, string subject, string message) {

            var mail = "brad@sandbox4597914f2f7e43619cc4a9227ec210fd.mailgun.org";
            var password = "75a00a1f732d848ba1dae30cdc5852c4-52d193a0-c0b179ce";

            var client = new SmtpClient("smtp.mailgun.org", 587)
            {
               EnableSsl= false,
                Credentials = new NetworkCredential(mail,password)
            };
            return client.SendMailAsync(new MailMessage(from: mail,
                to:email,subject,message));
        }
    }
}

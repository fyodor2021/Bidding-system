﻿namespace Assignment1Group26.Models
{
    public class HomeViewModel
    {
        public IEnumerable<Bid> Bids { get; set; }
        public IEnumerable<Category> Categories { get; set; }
        public IEnumerable<AssetCondition> AssetConditions { get; set; }
    }
}
